# Nota sobre las LLM, sus usos en FilosofíZate y la postura del autor

Alrededor de las nuevas herramientas generativas de texto existe actualmente una problemática considerable. Podemos decir que estas tecnologías han evolucionado mucho más rápidamente de lo que lo ha hecho el conocimiento general sobre su funcionamiento, sus fundamentos y su relación con conceptos como autoría u originalidad.

Descarto aquí hablar de propiedad porque, directamente, no considero que pueda hablarse de propiedad en el ámbito del conocimiento, ni siquiera en otros ámbitos. Pero esa es una cuestión que será tratada en FilosofíZate con detalle.

## Redes neuronales, información y generalización

Una red neuronal artificial, y entre ellas las arquitecturas que sustentan las LLM —grandes modelos de lenguaje—, constituye un sistema matemático-estadístico que aprende relaciones y regularidades a partir de determinados datos de entrada para producir salidas. Para ello es indispensable una fase de entrenamiento y, en el caso de las LLM, resulta crucial disponer de grandes conjuntos de textos.

Sin profundizar demasiado, podemos decir que el lenguaje escrito responde a convenciones ortográficas y gramaticales, así como a una compleja red de relaciones semánticas en constante desarrollo. Durante el entrenamiento, la red aprende estructuras y rasgos generalizables presentes en los datos. Mediante operaciones sobre representaciones de muy alta dimensionalidad —entre ellas, combinaciones lineales ponderadas en los núcleos de sus capas, junto con operaciones no lineales—, puede producir textos nuevos a partir de lo aprendido. No pretendo describir aquí toda la arquitectura, sino señalar la dependencia de esas operaciones respecto de las estructuras que el sistema ha aprendido.

Mi posición es que esas salidas, por novedosas que puedan parecer, dependen de las estructuras informacionales adquiridas durante el entrenamiento. No estoy hablando de copiar y pegar textos, ni de que una solución deba aparecer literalmente en los datos de entrada. Hablo de la información estructural: las relaciones y regularidades que permiten construir una solución, incluso cuando esa solución concreta no figuraba en ningún texto. La red puede generalizar esas estructuras con una eficacia extraordinaria, pero no puede independizarse de las condiciones desde las que aprendió a reconocerlas. Su capacidad para «ver» relaciones está condicionada por lo aprendido y, por tanto, también por los sesgos de ese aprendizaje. Naturalmente, durante su uso puede recibir información nueva del interlocutor; eso no elimina la dependencia de sus mecanismos de interpretación respecto de su formación previa.

En este sentido, distingo entre generalización e inferencia propiamente dicha. No utilizo aquí «inferencia» en su acepción habitual de obtener conclusiones a partir de premisas mediante reglas establecidas. A esa operación la considero una forma de generalización, o inferencia generacional: puede producir conclusiones inéditas, pero lo hace bajo un conjunto de restricciones que determina qué operaciones son posibles. Reservo la inferencia propiamente dicha para la actividad capaz de generar reglas que amplíen el espacio de posibilidades desde el que se construyen los problemas. No me refiero simplemente a modificar reglas ya existentes, ni siquiera cuando una regla autoriza a modificar otras. Esa modificación continúa siendo una posibilidad contemplada por el marco anterior. Me refiero a la generación de condiciones nuevas que hagan concebibles problemas antes inaccesibles desde dicho marco.

Por ello sostengo que las LLM poseen una capacidad extraordinaria de generalización, pero carecen de inferencia en el sentido que acabo de precisar. Desde esta perspectiva, el conocimiento humano no consiste únicamente en encontrar soluciones, sino también en hacer surgir nuevos problemas y las condiciones para formularlos. Esta distinción forma parte de mi posición filosófica; no pretende reproducir el uso convencional de estos términos en lógica o aprendizaje automático.

## Originalidad, lenguaje y edición

A menudo denominamos original a un texto por el mero hecho de haber sido escrito por un ser humano. Sin embargo, desde una perspectiva filológica, esta afirmación necesita matices. El lenguaje escrito responde a convenciones compartidas y a pautas que hemos aprendido mediante la exposición a otros usos del lenguaje. En ese sentido, buena parte de la expresión escrita consiste en reutilizar y reorganizar estructuras lingüísticas anteriores.

La originalidad humana no reside necesariamente en inventar un código nuevo para cada texto, sino en aquello que se intenta pensar y comunicar: las ideas, las relaciones que se establecen, las preguntas que se formulan y, cuando corresponde, las decisiones expresivas que también pueden ser originales.

Por eso considero que escribir un texto y someterlo a una revisión editorial humana es, en su función correctora, análogo a escribirlo y revisarlo con ayuda de una LLM. La analogía se refiere a esa tarea concreta, no a una equivalencia entre la naturaleza de una persona y la de una herramienta automática.

Si un editor humano realiza aportaciones originales, conceptuales o expresivas, puede ser razonable reconocerlas como tales. Pero si la intervención consiste en corregir ortografía, gramática o legibilidad, no por ello desaparece la autoría intelectual de quien ha desarrollado el texto.

Del mismo modo, cuando utilizo una herramienta automática para esa labor de corrección, considero que su uso no desmerece mi trabajo como autor. En mis publicaciones personales, y sin perjuicio de las obligaciones específicas que puedan existir en otros contextos contractuales, académicos o editoriales, entiendo que corresponde al autor decidir cómo informar sobre sus instrumentos de trabajo. Puede explicar que ha utilizado un corrector, un traductor automático, un procesador de textos o una LLM. Ninguna de esas herramientas determina por sí sola quién ha concebido las ideas.

## Sobre los detectores de textos generados por IA

Descalificar, infravalorar o relegar un texto porque un detector automático le atribuye un determinado porcentaje de probabilidad de haber sido generado mediante IA me parece una práctica profundamente cuestionable.

Estos sistemas trabajan mediante estimaciones y patrones estadísticos; no proporcionan, por sí mismos, una prueba concluyente de autoría. Un resultado expresado en forma de porcentaje no permite reconstruir con certeza el proceso intelectual y editorial que ha dado lugar a un escrito. Convertirlo en una sentencia puede perjudicar seriamente la transmisión de información y el reconocimiento del trabajo humano.

Naturalmente, hay situaciones diferentes. Si alguien debe elaborar personalmente un resumen para que se evalúe su capacidad de hacerlo y entrega uno generado íntegramente por una herramienta, resulta comprensible que se cuestione ese procedimiento conforme a las reglas de la evaluación. Pero eso no autoriza a equiparar la generación de un trabajo con la corrección lingüística de un texto previamente concebido y redactado por su autor.

## Lo que hago en FilosofíZate

Quiero explicarlo sin ambigüedades.

Yo escribo los textos de partida. Desarrollo mis ideas, establezco las relaciones entre ellas y las expreso con mi manera habitual de comunicarme. En ocasiones —o, probablemente, con bastante frecuencia— construyo frases demasiado largas y cometo determinadas incorrecciones ortográficas o gramaticales, en parte como consecuencia de las exigencias políglotas que he tenido que afrontar durante mi trayectoria profesional.

**Las ideas, los argumentos y las reflexiones que publico en FilosofíZate no nacen de un encargo a una LLM para que piense o escriba por mí.**

Lo que sí hago, por decisión propia, es contratar y utilizar servicios de LLM para revisar mis textos iniciales y mejorar su ortografía, su gramática y su legibilidad. Esa es la función editorial que les asigno, no la generación de mis ideas. Reviso las propuestas y decido qué modificaciones acepto para preservar el sentido de lo que quiero comunicar. La responsabilidad sobre las ideas y sobre el contenido finalmente publicado sigue siendo mía.

Si mi trabajo consistiera en demostrar que soy capaz de producir textos impecables desde el punto de vista ortográfico y gramatical sin ninguna asistencia, sería legítimo juzgarlo desde ese criterio. Pero esa no es mi tarea en FilosofíZate. Mi propósito es desarrollar ideas, reflexionar, explicar, formular problemas y compartirlos para su discusión.

Por ello, no entiendo que el simple uso de una herramienta de revisión lingüística pueda desmerecer ese trabajo. Una crítica fundada debería dirigirse a lo que digo, a la coherencia de mis argumentos, a sus presupuestos y a sus consecuencias, no a la mera sospecha de que he utilizado una tecnología para mejorar la presentación del texto.

## Técnica, conocimiento y crítica

La evolución de las técnicas ha facilitado tareas humanas durante milenios. Eso no significa necesariamente que las personas trabajen cada vez menos. Quienes procuran crecer técnica e intelectualmente pueden aprovechar los logros anteriores para plantear nuevos problemas y buscar soluciones. La herramienta no sustituye automáticamente el propósito de quien la utiliza.

Es necesario detenerse y estudiar. Tal vez una de las tareas pendientes para muchas personas sea comprender qué es una red neuronal, cómo funciona una LLM, cuáles son sus capacidades y cuáles sus límites. Solo desde ese conocimiento puede construirse una crítica verdaderamente informada.

No rechazo la crítica a estas tecnologías; considero que es necesaria. Lo que rechazo es la descalificación basada en el desconocimiento, especialmente cuando se convierte en un juicio sobre el trabajo intelectual de otras personas.

FilosofíZate está abierto al desacuerdo y al debate. No pido que se compartan mis conclusiones. Pido que se discutan mis ideas por lo que dicen y por las razones que las sostienen.

**La originalidad que reivindico no consiste en escribir sin herramientas, sino en pensar, formular y asumir la responsabilidad de lo que publico.**
